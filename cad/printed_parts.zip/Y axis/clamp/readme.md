You can choose between "Y LM8UU bearing clamp.stl", "Y bronce clamp.stl" and "Y IGUS bearing clamp.stl"

"Y clamp nut plate.stl" should be used only for "Y bronce clamp.stl".

For "Y LM8UU bearing clamp.stl" you will need 4 LM8UU linear bearings:
- inner diameter= 8mm
- outer diameter= 15mm
- length= 24mm

For "Y bronce clamps.stl" you will need 4 sinterized bronce bushings:
- inner diameter= 8mm
- outer diameter= 12mm
- length= 12mm

For "Y IGUS bearing clamp.stl" you will need 4 IGUS RJZM-01-08 linear bearings:
- inner diameter= 8mm
- outer diameter= 16mm
- length= 25mm
